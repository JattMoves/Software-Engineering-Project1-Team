from urllib.parse import urlparse
def detect_category(url: str) -> str:
    p = urlparse(url); host, path = p.netloc.lower(), p.path.strip('/')
    if host == 'huggingface.co':
        if path.startswith('datasets/'): return 'DATASET'
        parts = path.split('/')
        if len(parts) >= 2 and parts[0] and parts[1]: return 'MODEL'
    if host in {'github.com','gitlab.com'}: return 'CODE'
    return 'UNKNOWN'
def model_id_from_hf_url(url: str) -> str | None:
    p = urlparse(url)
    if p.netloc.lower() != 'huggingface.co': return None
    parts = p.path.strip('/').split('/')
    if not parts or parts[0]=='datasets': return None
    if len(parts) >= 2: return f"{parts[0]}/{parts[1]}"
    return None
