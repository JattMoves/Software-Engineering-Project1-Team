import logging, os
def configure_logging() -> None:
    lvl = os.getenv("LOG_LEVEL", "0")
    level = logging.CRITICAL + 1
    if lvl == "1": level = logging.INFO
    elif lvl == "2": level = logging.DEBUG
    handlers = []
    path = os.getenv("LOG_FILE")
    if path:
        try: handlers.append(logging.FileHandler(path, encoding="utf-8"))
        except Exception: handlers.append(logging.NullHandler())
    else:
        handlers.append(logging.NullHandler())
    logging.basicConfig(level=level, handlers=handlers,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        force=True)
