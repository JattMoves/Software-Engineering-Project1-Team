from acmecli.metrics.ramp_up import _cap_ratio,_freshness_score
def test_cap_ratio_bounds():
    assert _cap_ratio(0,100)==0.0
    assert _cap_ratio(50,100)==0.5
    assert _cap_ratio(100,100)==1.0
    assert _cap_ratio(200,100)==1.0
def test_freshness_range(): assert 0.3 <= _freshness_score(None) <= 1.0
