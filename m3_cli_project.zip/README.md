# M3 CLI (HF Ramp-Up)

Usage:
./run install
./run <ABS_PATH_TO_URL_FILE>
./run test
